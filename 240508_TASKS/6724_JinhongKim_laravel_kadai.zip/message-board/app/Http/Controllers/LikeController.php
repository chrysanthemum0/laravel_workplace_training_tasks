<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LikeController extends Controller
{
    public function index()
    {
        $messages = \Auth::user()->likeMessages()
                ->orderBy('created_at', 'desc')->paginate(20);
                return view('likes.index', ['messages' => $messages]);
    }

    //
    public function store(Request $request)
    {
        //카운트
        //$like_sum = Like::where('message',$message_id)->where('user_id','1') -> count('like_no');
        \Auth::user()->likeMessages()->attach($request->message_id);
        return back();
    }

    public function destroy(Request $request)
    {
        \Auth::user()->likeMessages()->detach($request->message_id);
        return back();
    }
}

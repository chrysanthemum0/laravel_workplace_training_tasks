<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        // Step3：自分の投稿を新しい順で１ページあたり10件分取得
        $messages = \Auth::user()->messages()->orderBy('created_at', 'desc')->paginate();
        return view('home.index', ['messages' => $messages]);
    }
    
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    use HasFactory;
    
    // Step3：fillableプロパティはcontentのみ
    protected $fillable = ['content'];

    // Step2：Userとの一対多リレーション
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}

<?php $__env->startSection('content'); ?>
<h1>マイページ</h1>
<!-- Step3：メッセージ投稿フォーム -->
<?php echo $__env->make('commons.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(route('messages.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <p>
        <textarea name="content" rows="3" placeholder="メッセージを入力"></textarea>
    </p>
    <p>
        <button type="submit">投稿する</button>
    </p>
</form>

<!-- Step3：自分のメッセージ一覧表示 -->
<ul class="message-list">
    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <div><?php echo e($message->user->name); ?>：<?php echo e($message->created_at); ?></div>
        <div><?php echo nl2br(e($message->content)); ?></div>
        <div>
            <a href="<?php echo e(route('messages.edit', $message->id)); ?>">編集</a>
        </div>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($messages->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\student\Desktop\laravel-kadai\message-board\resources\views/home/index.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
<h1>プロフィール編集</h1>
<?php echo $__env->make('commons.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(route('profile.update')); ?>" method="post">
    <?php echo csrf_field(); ?> 
    <?php echo method_field('patch'); ?>
    <p>
        <label>名前</label><br>
        <input type="text" name="name" value="<?php echo e($user->name); ?>">
    </p>
    <p>
        <button type="submit">更新する</button>
    </p>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\laravel-kadai\message-board\resources\views/home/edit.blade.php ENDPATH**/ ?>
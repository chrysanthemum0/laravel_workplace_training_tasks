<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo e(config('app.name')); ?></title>
    <link rel="stylesheet" href="/css/main.css">
</head>
<body>
    <header>
        <div class="container">
            <a class="brand" href="/"><?php echo e(config('app.name')); ?></a>
            <?php if(Auth::check()): ?>
            <ul class="navigation">
                <li><a href="<?php echo e(route('home')); ?>">マイページ</a></li>
                <li><a href="<?php echo e(route('messages.index')); ?>">みんなの投稿</a></li>
                <li>
                    <a href="#" onclick="logout()">ログアウト</a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                    </form>
                    <script>
                        function logout() {
                            event.preventDefault();
                            if (window.confirm('ログアウトしますか？')) {
                                document.getElementById('logout-form').submit();
                            }
                        }
                    </script>
                </li>
            </ul>
            <?php endif; ?>
        </div>
    </header>
    <main>
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
</body>
</html><?php /**PATH C:\Users\student\Desktop\laravel-kadai\message-board\resources\views/layouts/app.blade.php ENDPATH**/ ?>
<?php if($errors->count()): ?>
<ul class="alert">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?><?php /**PATH C:\Users\USER\Desktop\laravel-kadai\lv40\message-board\resources\views/commons/flash.blade.php ENDPATH**/ ?>
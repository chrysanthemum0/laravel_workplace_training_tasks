<?php $__env->startSection('content'); ?>
<h1>メッセージ編集</h1>
<!-- Step4：メッセージ編集フォーム -->
<?php echo $__env->make('commons.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(route('messages.update', $message->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('patch'); ?>
    <p>
        <textarea name="content" rows="3" placeholder="メッセージを入力"><?php echo e(old('content', $message->content)); ?></textarea>
    </p>
    <p>
        <button type="submit">更新する</button>
        <a href="<?php echo e(route('home')); ?>">キャンセル</a>
    </p>

</form>

<!-- Step5：削除ボタン -->
<form onsubmit="return confirm('本当に削除しますか？')" action="<?php echo e(route('messages.destroy', $message->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('delete'); ?>
    <button type="submit">削除</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\student\Desktop\laravel-kadai\message-board\resources\views/messages/edit.blade.php ENDPATH**/ ?>
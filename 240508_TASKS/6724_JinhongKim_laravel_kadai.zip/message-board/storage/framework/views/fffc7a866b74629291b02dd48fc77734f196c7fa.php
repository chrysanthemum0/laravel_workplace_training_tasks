<ul class="message-list">
    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <div><?php echo e($message->user->name); ?>：<?php echo e($message->created_at); ?></div>
        <div><?php echo e($message->content); ?></div>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
</ul><?php /**PATH C:\Users\USER\Desktop\laravel-kadai\lv40\message-board\resources\views/commons/messages.blade.php ENDPATH**/ ?>
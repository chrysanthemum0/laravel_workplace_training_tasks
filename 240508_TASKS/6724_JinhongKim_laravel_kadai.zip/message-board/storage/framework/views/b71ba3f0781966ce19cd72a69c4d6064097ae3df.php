

<?php $__env->startSection('content'); ?>
<h1>マイページ</h1>
<h2>ようこそ <?php echo e(Auth::user()->name); ?> さん！</h2>
<form action="<?php echo e(route('logout')); ?>" method="post">
    <?php echo csrf_field(); ?> 
    <button type="submit">ログアウト</button>
</form>

<!-- Step4オプション問題用 -->
<p><a href="<?php echo e(route('profile.edit')); ?>">プロフィール編集</a></p>

<!-- Step5オプション問題用 -->
<form action="<?php echo e(route('users.delete')); ?>" method="post">
    <?php echo csrf_field(); ?> 
    <?php echo method_field('delete'); ?>
    <button type="submit">退会する</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\laravel-kadai\message-board\resources\views/home/index.blade.php ENDPATH**/ ?>
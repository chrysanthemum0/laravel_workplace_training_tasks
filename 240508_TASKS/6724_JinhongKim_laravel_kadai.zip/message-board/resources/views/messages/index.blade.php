@extends('layouts.app')

@section('content')

<!-- Step3：みんなの投稿ページ -->
<h1>みんなの投稿</h1>
<ul class="message-list">
    @foreach($messages as $message)
    <li>
        <div>{{ $message->user->name }}：{{ $message->created_at }}</div>
        <div>{!! nl2br(e($message->content)) !!}</div>
        @if($message->user_id == Auth::id())
        <div>
            <a href="{{ route('messages.edit', $message->id) }}">編集</a>
        </div>
        @else
            @if(Auth::user()->isLike($message->id))
            <form action="{{ route('likes.destroy') }}" method="post" >
                @csrf
                @method('delete')
                <input type="hidden" name="message_id" value="{{ $message->id }}">
                <button type="submit">イイネ削除</button>
                <span>　：人がいいね！と言っています！</span>
            </form>
            @else
            <form action="{{ route('likes.store') }}" method="post" >
                @csrf
                <input type="hidden" name="message_id" value="{{ $message->id }}">
                <button type="submit">イイネ！</button>
                <span>　：人がいいね！と言っています！</span>
            </form>
            @endif
        @endif
    </li>
    @endforeach
</ul>
{{ $messages->links() }}
@endsection

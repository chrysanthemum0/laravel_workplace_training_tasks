@extends('layouts.app')

@section('content')
<h1>マイページ</h1>
<!-- Step3：メッセージ投稿フォーム -->
@include('commons.flash')
<form action="{{ route('messages.store') }}" method="post">
    @csrf
    <p>
        <textarea name="content" rows="3" placeholder="メッセージを入力"></textarea>
    </p>
    <p>
        <button type="submit">投稿する</button>
    </p>
</form>

<!-- Step3：自分のメッセージ一覧表示 -->
<ul class="message-list">
    @foreach($messages as $message)
    <li>
        <div>{{ $message->user->name }}：{{ $message->created_at }}</div>
        <div>{!! nl2br(e($message->content)) !!}</div>
        <div>
            <a href="{{ route('messages.edit', $message->id) }}">編集</a>
        </div>
    </li>
    @endforeach
</ul>
{{ $messages->links() }}
@endsection

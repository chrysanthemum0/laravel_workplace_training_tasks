<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name')); ?></title>
</head>
<body>
    <h1>商品一覧</h1>

    <a href="<?php echo e(route('items.create')); ?>">+新規作成</a>
    <br>


<form action="<?php echo e(route('items.index')); ?>" method="post" novalidate>
    <?php echo csrf_field(); ?>
    カテゴリー
    <select name="category_id">
        <option value="">(未選択)</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    <br>

    商品名
    <input type="text" name="keyword" value="<?php echo e($search_keyword); ?>">
    <br>

    値段の範囲
    <input type="text" name="price_min" value="<?php echo e($search_price_min); ?>" size="4">～
    <input type="text" name="price_max" value="<?php echo e($search_price_max); ?>" size="4">
    <br>

    並び替え
    <select name="sort" id="">
        <option value="">(なし)
        <option value="price_asc" <?php echo e($search_sort == "price_asc" ? " selected" : ""); ?>>値段の安い順
        <option value="price_desc" <?php echo e($search_sort == "price_desc" ? " selected" : ""); ?>>値段の高い順
    </select>
    <br>
    <hr>
    <button type="submit">検索</button>
</form>

    <table border="1">
        <thead>
            <tr>
                <th></th>
                <th>ID</th>
                <th>顧客名</th>
                <th>分類</th>
                <th>値段</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <a href="<?php echo e(route('items.show', $item->id)); ?>">詳細</a>
                </td>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->category->name); ?></td>
                <td><?php echo e($item->price); ?>円</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\student\Desktop\6724_JinhongKim_laravel_exam\laravel_exam\resources\views/items/index.blade.php ENDPATH**/ ?>
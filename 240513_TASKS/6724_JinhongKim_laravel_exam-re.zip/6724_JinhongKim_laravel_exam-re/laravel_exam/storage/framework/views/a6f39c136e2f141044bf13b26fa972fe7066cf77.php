<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h1>商品新規作成</h1>
<?php echo $__env->make('commons.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="<?php echo e(route('items.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <dl>
            <dt>商品名</dt>
            <dd>
                <dd>
                    <input type="text" name="name" value="" placeholder="" />
                </dd>
            </dd>

            <dt>分類</dt>
            <dd>
                <select name="category_id" id="">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </dd>

            <dt>値段</dt>
            <dd>
                <input type="number" name="price" value="" placeholder="" />円
            </dd>
        </dl>
        <button type="submit">登録</button>
        <hr>
        <a href="<?php echo e(route('items.index')); ?>">戻る</a>

</body>
</html>
<?php /**PATH C:\Users\student\Desktop\6724_JinhongKim_laravel_exam\laravel_exam\resources\views/items/create.blade.php ENDPATH**/ ?>
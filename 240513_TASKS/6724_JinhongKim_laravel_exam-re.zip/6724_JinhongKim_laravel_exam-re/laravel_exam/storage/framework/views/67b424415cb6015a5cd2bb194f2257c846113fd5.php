<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name')); ?></title>
</head>
<body>
    <h1>商品詳細</h1>
    <h3><?php echo e($item->name); ?></h3>

    <p>
        ID : <?php echo e($item->id); ?>

    </p>
    <p>
        分類 : <?php echo e($item->category->name); ?>

    </p>
    <p>
        価格 : <?php echo e($item->price); ?>

    </p>


    <a href="<?php echo e(route('items.edit', $item->id)); ?>">編集する</a>
    <a href="<?php echo e(route('items.index')); ?>">戻る</a>
    <hr>
    <a href="#" onclick="deleteItem()">削除する</a>
    <form action="<?php echo e(route('items.destroy', $item->id)); ?>" method="post" id="delete-form">
      <?php echo csrf_field(); ?>
      <?php echo method_field('delete'); ?>
    </form>
    <script type="text/javascript">
      function deleteItem() {
        event.preventDefault();
        if (window.confirm('本当に削除しますか？')) {
        document.getElementById('delete-form').submit();
        }
      }
    </script>
</body>
</html>
<?php /**PATH C:\Users\student\Desktop\6724_JinhongKim_laravel_exam\laravel_exam\resources\views/items/show.blade.php ENDPATH**/ ?>
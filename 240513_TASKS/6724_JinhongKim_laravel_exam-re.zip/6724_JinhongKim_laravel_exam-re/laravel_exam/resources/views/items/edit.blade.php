<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{config('app.name')}}</title>
</head>
<body>
<h1>商品情報の編集</h1>
@include('commons.flash')

    <form action="{{ route('items.update', $item->id) }}" method="post">
        @csrf
        @method('patch')

        <dl>
            <dt>商品名</dt>
            <dd>
                <dd>
                    <input type="text" name="name" value="{{$item->name}}" placeholder="" />
                </dd>
            </dd>

            <dt>分類</dt>
            <dd>
                <select name="category_id" id="">
                    @foreach ($categories as $category)
                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                    @endforeach
                </select>
            </dd>

            <dt>値段</dt>
            <dd>
                <input type="number" name="price" value="{{$item->price}}" placeholder="" />円
            </dd>
        </dl>
        <button type="submit">登録</button>
        <hr>
        <a href="{{ route('items.index') }}">戻る</a>

</body>
</html>

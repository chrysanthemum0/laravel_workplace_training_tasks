<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{config('app.name')}}</title>
</head>
<body>
    <h1>商品詳細</h1>
    <h3>{{$item->name}}</h3>

    <p>
        ID : {{ $item->id }}
    </p>
    <p>
        分類 : {{ $item->category->name }}
    </p>
    <p>
        価格 : {{ $item->price }}
    </p>


    <a href="{{ route('items.edit', $item->id) }}">編集する</a>
    <a href="{{ route('items.index') }}">戻る</a>
    <hr>
    <a href="#" onclick="deleteItem()">削除する</a>
    <form action="{{ route('items.destroy', $item->id)}}" method="post" id="delete-form">
      @csrf
      @method('delete')
    </form>
    <script type="text/javascript">
      function deleteItem() {
        event.preventDefault();
        if (window.confirm('本当に削除しますか？')) {
        document.getElementById('delete-form').submit();
        }
      }
    </script>
</body>
</html>

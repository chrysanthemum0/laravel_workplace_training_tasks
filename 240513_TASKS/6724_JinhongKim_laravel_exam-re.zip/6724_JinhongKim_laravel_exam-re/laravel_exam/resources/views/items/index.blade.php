<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{config('app.name')}}</title>
</head>
<body>
    <h1>商品一覧</h1>

    <a href="{{ route('items.create') }}">+新規作成</a>
    <br>


<form action="{{ route('items.index') }}" method="post" novalidate>
    @csrf
    カテゴリー
    <select name="category_id">
        <option value="">(未選択)</option>
        @foreach ($categories as $category)
          <option value="{{ $category->id }}">{{ $category->name }}</option>
        @endforeach
      </select>
    <br>

    商品名
    <input type="text" name="keyword" value="{{ $search_keyword }}">
    <br>

    値段の範囲
    <input type="text" name="price_min" value="{{ $search_price_min }}" size="4">～
    <input type="text" name="price_max" value="{{ $search_price_max }}" size="4">
    <br>

    並び替え
    <select name="sort" id="">
        <option value="">(なし)
        <option value="price_asc" {{ $search_sort == "price_asc" ? " selected" : "" }}>値段の安い順
        <option value="price_desc" {{ $search_sort == "price_desc" ? " selected" : "" }}>値段の高い順
    </select>
    <br>
    <hr>
    <button type="submit">検索</button>
</form>

    <table border="1">
        <thead>
            <tr>
                <th></th>
                <th>ID</th>
                <th>顧客名</th>
                <th>分類</th>
                <th>値段</th>
            </tr>
        </thead>
        <tbody>
            @foreach($items as $item)
            <tr>
                <td>
                    <a href="{{ route('items.show', $item->id) }}">詳細</a>
                </td>
                <td>{{ $item->id }}</td>
                <td>{{ $item->name }}</td>
                <td>{{ $item->category->name}}</td>
                <td>{{ $item->price}}円</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>

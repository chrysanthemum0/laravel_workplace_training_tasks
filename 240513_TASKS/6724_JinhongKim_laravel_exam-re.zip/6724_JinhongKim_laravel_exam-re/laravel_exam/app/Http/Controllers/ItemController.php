<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Item;
use App\Models\Category;

class ItemController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //
        $items = \App\Models\Item::all();
        $categories = Category::all();
        $search_category_id = "";
        $search_keyword = "";
        $search_price_min = "";
        $search_price_max = "";
        $search_sort = "";

        if( isset($request->keyword))
        {
            $search_keyword = $request->keyword;
        }
        $items = Item::where('name', 'LIKE', '%' . $search_keyword . '%');

        if( isset($request->category_id))
        {
            $search_category_id = $request->category_id;
            $items = $items -> where('category_id' , '=', $search_category_id);
        }

        if( isset($request->price_min))
        {
            $search_price_min = $request->price_min;
            $items = $items -> where('price', '>=', $search_price_min);
        }
        if( isset($request->price_max))
        {
            $search_price_max = $request->price_max;
            $items = $items -> where('price', '<=', $search_price_max);
        }
        if( isset($request->sort))
        {
            $search_sort = $request->sort;
            if ($search_sort == "price_asc")
            {
                $items = $items -> orderBy('price', 'asc');
            }
            if ($search_sort == "price_desc")
            {
                $items = $items -> orderBy('price', 'desc');
            }
        } else {
            $items = $items -> orderBy('created_at', 'desc');
        }
        $items = $items ->get();

        return view('items.index', ['items' => $items,
                                    'categories' => $categories,
                                    'search_category_id' => $search_category_id,
                                    'search_keyword' => $search_keyword,
                                    'search_price_min' => $search_price_min,
                                    'search_price_max' => $search_price_max,
                                    'search_sort' => $search_sort]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $items = Item::all();
        $categories = Category::all();

        return view('items.create', [
            'items' => $items,
            'categories' => $categories,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
                // 입력된 데이터의 유효성을 검사합니다.
                $this->validate($request, [
                    'name' => 'required', //
                    'price' => 'required|integer', //
                ]);

                $item = new Item;
                $item->category_id = $request->category_id;
                $item->name = $request->name;
                $item->price = $request->price;
                $item->save();
                return redirect(route('items.index'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Item $item)
    {
        return view('items.show', ['item' => $item]);
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Item $item)
    {
        //
        $categories = Category::all();

        return view('items.edit', [
            'item' => $item, 'categories'=>$categories
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Item $item)
    {
        //
        $item->name = $request->name;
        $item->category_id = $request->category_id;
        $item->price = $request->price;
        $item->save();
        return redirect(route('items.show', $item->id));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Item $item)
    {
        //
        $item->delete();
        return redirect(route('items.index'));
    }
}

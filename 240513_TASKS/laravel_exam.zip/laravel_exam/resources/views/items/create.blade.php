<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>商品新規作成</title>
  </head>
  <body>
    <h1>商品新規作成</h1>
    <form action="{{ route('items.store') }}" method="post">
      @csrf
      <dl>
        <dt>商品名</dt>
        <dd><input type="text" name="name" required></dd>
        <dt>分類</dt>
        <dd>
          <select name="category_id">
          @foreach ($categories as $category)
            <option value="{{ $category->id }}">{{ $category->name }}
          @endforeach
          </select>
        </dd>
        <dt>価格</dt>
        <dd><input type="number" name="price" required>円</dd>
      </dl>
      <button type="submit">登録する</button>
    </form>
    <hr>
    <a href="{{ route('items.index') }}">戻る</a>
  </body>
</html>
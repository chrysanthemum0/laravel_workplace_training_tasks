<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>商品編集</title>
  </head>
  <body>
    <h1>商品情報の編集</h1>
    <form action="{{ route('items.update', $item->id) }}" method="post">
      @csrf
      @method('patch')

      <dl>
        <dt>商品名</dt>
        <dd><input type="text" name="name" value="{{ $item->name }}"></dd>
        <dt>分類</dt>
        <dd>
          <select name="category_id">
            @foreach ($categories as $category)
              <option value="{{ $category->id }}"{{ $category->id == $item->category_id ? " selected" : "" }}>{{ $category->name }}
            @endforeach
          </select>
        </dd>

        <dt>価格</dt>
          <dd><input type="text" name="price" value="{{ $item->price }}">円</dd>
      </dl>
      <button type="submit">更新する</button>
    </form>
    <hr>
    <a href="{{ route('items.index') }}">戻る</a>
  </body>
</html>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>商品一覧</title>
</head>

<body>
  <h1>商品一覧</h1>

  <p><a href="{{ route('items.create') }}">＋新規作成</a></p>

  <form action="{{ route('items.index') }}" method="get">
    カテゴリー
    <select name="category_id">
      <option value="">(未選択)
      @foreach ($categories as $category)
        <option value="{{ $category->id }}"{{$search_category_id == $category->id ? " selected" : "" }}>{{ $category->name }}
      @endforeach
    </select>
    <br>
    商品名
    <input type="text" name="keyword" value="{{ $search_keyword }}">
    <br>
    値段の範囲
    <input type="text" name="price_min" value="{{ $search_price_min }}" size="4">～
    <input type="text" name="price_max" value="{{ $search_price_max }}" size="4">
    <br>
    並び替え
    <select name="sort">
      <option value="">(なし)
      <option value="price_asc" {{ $search_sort == "price_asc" ? " selected" : "" }}>値段の安い順
      <option value="price_desc" {{ $search_sort == "price_desc" ? " selected" : "" }}>値段の高い順
    </select>
    <br>
    <button type="submit">検索</button>
  </form>

  <table border="1">
    <tr>
      <th></th>
      <th>ID</th>
      <th>商品名</th>
      <th>分類</th>
      <th>値段</th>
    </tr>
    @foreach ($items as $item)
      <tr>
        <td><a href="/items/{{ $item->id }}">詳細</a></td>
        <td>{{ $item->id }}</td>
        <td>{{ $item->name }}</td>
        <td>{{ $item->category->name }}</td>
        <td>{{ $item->price }}円</td>
      </tr>
    @endforeach
  </table>

  </body>
</html>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>商品一覧</title>
</head>
<body>
<h1>商品一覧</h1>
<p><a href="<?php echo e(route('items.create')); ?>">＋新規作成</a></p>

<form action="<?php echo e(route('items.index')); ?>" method="get">
  カテゴリー
  <select name="category_id">
    <option value="">(未選択)
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($category->id); ?>"<?php echo e($search_category_id == $category->id ? " selected" : ""); ?>><?php echo e($category->name); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <br>

  商品名
  <input type="text" name="keyword" value="<?php echo e($search_keyword); ?>">
  <br>

  値段の範囲
  <input type="text" name="price_min" value="<?php echo e($search_price_min); ?>" size="4">～
  <input type="text" name="price_max" value="<?php echo e($search_price_max); ?>" size="4">
  <br>

  並び替え
  <select name="sort">
    <option value="">(なし)
    <option value="price_asc" <?php echo e($search_sort == "price_asc" ? " selected" : ""); ?>>値段の安い順
    <option value="price_desc" <?php echo e($search_sort == "price_desc" ? " selected" : ""); ?>>値段の高い順
  </select>
  <br>
  <button type="submit">検索</button>

</form>

<table border="1">
  <tr>
    <th>
    <th>ID
    <th>商品名
    <th>分類
    <th>値段
  </tr>

<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><a href="/items/<?php echo e($item->id); ?>">詳細</a>
    <td><?php echo e($item->id); ?>

    <td><?php echo e($item->name); ?>

    <td><?php echo e($item->category->name); ?>

    <td><?php echo e($item->price); ?>円
  </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

</body>
</html><?php /**PATH C:\Users\USER\TechImprovements\13_PHP講座\02_Laravel\テスト\laravel_exam\resources\views/items/index.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>商品新規作成</title>
</head>
<body>
<h1>商品新規作成</h1>
<form action="<?php echo e(route('items.store')); ?>" method="post">
<?php echo csrf_field(); ?>
<dl>
<dt>商品名</dt>
<dd><input type="text" name="name" required></dd>
<dt>分類</dt>
<dd>
  <select name="category_id">
  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
</dd>
<dt>価格</dt>
<dd><input type="number" name="price" required>円</dd>
</dl>
<button type="submit">登録する</button>
</form>
<hr>
<a href="<?php echo e(route('items.index')); ?>">戻る</a>
</body>
</html><?php /**PATH C:\Users\USER\TechImprovements\13_PHP講座\02_Laravel\テスト\laravel_exam\resources\views/items/create.blade.php ENDPATH**/ ?>
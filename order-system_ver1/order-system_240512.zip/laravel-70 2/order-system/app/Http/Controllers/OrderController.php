<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use App\Models\Customer;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    /**
     * 주문 목록을 페이징하여 보여줍니다.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // 주문 목록을 페이징하여 가져옵니다.
        $orders = Order::paginate(10);
        return view('orders.index', ['orders' => $orders]);
    }

    /**
     * 새 주문을 생성하는 폼을 보여줍니다.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        // 모든 상품과 고객 정보를 조회하여 주문 생성 폼에 전달합니다.
        $products = Product::all();
        $customers = Customer::all();

        return view('orders.create', [
            'customers' => $customers,
            'products' => $products,
        ]);
    }

    /**
     * 새 주문을 저장합니다.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // 입력된 데이터의 유효성을 검사합니다.
        $this->validate($request, [
            'product_id' => 'required', // 상품 ID 필수
            'customer_id' => 'required', // 고객 ID 필수
            'quantity' => 'required|integer|min:1|max:999', // 수량 필수, 정수여야 하며 최소 1에서 최대 999
        ]);
    
        // 요청된 상품 ID에 해당하는 상품을 조회합니다.
        $product = Product::findOrFail($request->product_id);
    
        // 새로운 주문 인스턴스를 생성합니다.
        $order = new \App\Models\Order;
    
        // 주문에 고객 ID, 상품 ID, 수량을 설정합니다.
        $order->customer_id = $request->customer_id;
        $order->product_id = $request->product_id;
        $order->quantity = $request->quantity;
    
        // 선택된 상품의 가격을 가져와서 주문에 할당합니다.
        $product = Product::find($request->product_id);
        $order->unit_price = $product->price;
    
        // 주문을 저장합니다.
        $order->save();
    
        // 주문 목록 페이지로 리다이렉트합니다.
        return redirect(route('orders.index'));
    }
    

    /**
     * 주문을 상세하게 보여줍니다.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Order $order)
    {
        // 주문을 상세하게 보여줍니다.
        return view('orders.show', ['order' => $order]);
    }

    /**
     * 주문 수정 폼을 보여줍니다.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Order $order)
    {
        // 수정할 주문의 상세 정보와 모든 상품 및 고객 정보를 조회하여 수정 폼에 전달합니다.
        $products = Product::all();
        $customers = Customer::all();

        return view('orders.edit', [
            'order' => $order,
            'products' => $products,
            'customers' => $customers,
        ]);
    }

    /**
     * 주문을 업데이트합니다.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Order $order)
    {
        // 입력된 데이터의 유효성을 검사합니다.
        $this->validate($request, [
            'customer_id' => 'required',
            'product_id' => 'required',
            'quantity' => 'required|integer|min:1|max:999',
            'unit_price' => 'required|integer|min:1',
            'shipped_on' => 'nullable|date',
        ]);
        
        // 주문 정보를 업데이트합니다.
        $order->update($request->all());
        
        // 수정된 주문 페이지로 리다이렉트합니다.
        return redirect(route('orders.show', $order->id));
    }

    /**
     * 주문을 삭제합니다.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Order $order)
    {
        // 주문을 삭제합니다.
        $order->delete();
        
        // 주문 목록 페이지로 리다이렉트합니다.
        return redirect(route('orders.index'));
    }
}


// 'orders' => $orders 부분은 view에 데이터를 전달하는 부분입니다. Blade 템플릿에서는 해당 데이터를 사용할 수 있습니다.

// 여기서 'orders'는 view에서 사용할 변수 이름을 나타내고, $orders는 컨트롤러에서 전달하는 데이터입니다. 
// 즉, 'orders'라는 이름으로 $orders 변수를 view에 전달하여 해당 변수를 사용할 수 있도록 하는 것입니다.

// Blade 템플릿에서는 이렇게 전달된 데이터를 {{ $orders }}와 같은 형태로 사용할 수 있습니다. 이것은 변수를 출력하는 Blade 문법입니다.

// 따라서 'orders' => $orders 부분은 컨트롤러에서 전달한 $orders 데이터를 view에 'orders'라는 이름으로 전달하는 것을 의미합니다.

// $order->customer_id는 새로운 주문 객체인 $order의 속성 중 하나인 customer_id를 나타냅니다. 이 속성은 주문이 속한 고객의 ID를 저장합니다.

// 따라서 $request->customer_id의 값은 클라이언트가 제출한 데이터이며, 이 값은 $order->customer_id에 할당되어 새로운 주문 객체의 속성으로 설정됩니다.
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use HasFactory;

    // 'name' 필드를 대량 할당할 수 있도록 지정
    protected $fillable = ['name'];

    // Customer 모델과 Order 모델 간의 일대다 관계 설정
    public function orders()
    {
        return $this->hasMany(Order::class);
    }

    // Customer 모델과 Product 모델 간의 다대다 관계 설정
    // 'orders' 테이블을 중간 피벗 테이블로 사용
    public function products()
    {
        return $this->belongsToMany(Product::class, 'orders');
    }
}


// Customer 클래스는 Model 클래스를 확장하여 데이터베이스 테이블과 상호 작용하는 Eloquent 모델을 정의합니다.
// HasFactory 트레이트를 사용하여 팩토리 메서드를 제공하며, 모델 팩토리를 사용하여 테스트 데이터를 생성할 수 있습니다.
// fillable 속성은 대량 할당을 허용하는 필드를 정의합니다. 여기서는 name 필드만을 대량 할당할 수 있도록 설정되어 있습니다.
// orders 메서드는 Customer 모델과 Order 모델 간의 일대다 관계를 정의합니다. 즉, 하나의 고객은 여러 개의 주문을 가질 수 있습니다.
// products 메서드는 Customer 모델과 Product 모델 간의 다대다 관계를 정의합니다. 즉, 한 명의 고객이 여러 제품을 주문할 수 있고, 
// 하나의 제품을 여러 명의 고객이 주문할 수 있습니다. 이 관계에서는 orders 테이블이 중간 피벗 테이블로 사용됩니다.
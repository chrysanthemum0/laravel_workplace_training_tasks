<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    // 'product_id', 'customer_id', 'qunatity', 'unit_price', 'shipped_on' 필드를 대량 할당할 수 있도록 지정
    protected $fillable = ['product_id', 'customer_id', 'qunatity', 'unit_price', 'shipped_on'];

    // 'shipped_on' 필드를 날짜 형식으로 변환
    //protected $dates = ['shipped_at'];

    // Order 모델과 Product 모델 간의 일대다 관계 설정
    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    // Order 모델과 Customer 모델 간의 일대다 관계 설정
    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }
}


// Order 클래스는 Model 클래스를 확장하여 데이터베이스 테이블과 상호 작용하는 Eloquent 모델을 정의합니다.
// HasFactory 트레이트를 사용하여 팩토리 메서드를 제공하며, 모델 팩토리를 사용하여 테스트 데이터를 생성할 수 있습니다.
// fillable 속성은 대량 할당을 허용하는 필드를 정의합니다. 여기서는 product_id, customer_id, quantity, unit_price, shipped_on 필드가 대량 할당될 수 있도록 설정되어 있습니다.
// product 메서드는 Order 모델과 Product 모델 간의 일대다 관계를 정의합니다. 즉, 하나의 주문은 하나의 제품을 가질 수 있습니다.
// customer 메서드는 Order 모델과 Customer 모델 간의 일대다 관계를 정의합니다. 즉, 하나의 주문은 하나의 고객에게 속할 수 있습니다.
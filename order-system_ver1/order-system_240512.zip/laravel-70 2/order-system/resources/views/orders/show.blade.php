@extends('layouts.app')

@section('content')
<h1>注文詳細</h1>
@include('commons.flash')
<table>
    <tr>
        <th>注文ID</th>
        <td>{{ $order->id }}</td>
    </tr>
    <tr>
        <th>顧客</th>
        <td>{{ $order->customer->id }} : {{$order->customer->name }}</td>
    </tr>
    <tr>
        <th>商品</th>
        <td>{{ $order->product->id }}: {{ $order->product->name }}</td>
    </tr>
    <tr>
        <th>注文数</th>
        <td>{{ $order->quantity }}</td>
    </tr>
    <tr>
        <th>購入単価</th>
        <td>{{ $order->product->price }}円</td>
    </tr>
    <tr>
        <th>注文合計金額</th>
        <td>{{ $order->unit_price}}円</td>
    </tr>
    <tr>
        <th>注文日</th>
        <td>{{ $order->created_at }}</td>
    <tr>
    </tr>
    @if (isset($order->shipped_on))
    <tr>
        <th>発送日</th>
        <td>{{ $order->shipped_on }}</td>
    </tr>
    @else
    <tr>
        <th>発送日</th>
        <td>未発送</td>
    </tr>
@endif
</table>

<a href="{{ route('orders.edit', $order) }}">編集する</a>

<hr>
    <a href="#" onclick="deleteOrder()">注文を削除</a>
    <form action="{{ route('orders.destroy', $order) }}" method="post" id="delete-form" novalidate>
        @csrf
        @method('delete')
    </form>
    <script type="text/javascript">
        function deleteOrder() {
            event.preventDefault();
            if (window.confirm('本当に削除しますか？')) {
                document.getElementById('delete-form').submit();
            }
        }
    </script>

@endsection

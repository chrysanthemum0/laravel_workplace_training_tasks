@extends('layouts.app')

@section('content')
<h1>注文登録</h1>
@include('commons.flash')

<form action="{{ route('orders.store') }}" method="post">
    @csrf
    <dl>
        <dt>顧客名</dt>
        <dd>
            <select name="customer_id" id="">
                @foreach ($customers as $customer)
                <!-- value 속성에 $customer->id 찾아온 후 드롭박스로 customers테이블에서 name 출력  -->
                <option value="{{ $customer->id }}">{{ $customer->name }} 様</option>
                @endforeach
            </select>
        </dd>
        <dt>商品を選択</dt>
        <dd>
            <select name="product_id" id="">
                @foreach($products as $product)
                <option value="{{ $product->id }}">{{ $product->name }}
                    ({{ $product->category->name }})
                </option>
                @endforeach
            </select>
        </dd>
        <dt>注文数</dt>
        <dd>
            <input type="number" name="quantity" value="" placeholder="数を入力" />個
        </dd>
    </dl>
    <button type="submit">登録</button>

</form>
</body>
</html>
@endsection

@extends('layouts.app')

@section('content')
<h1>注文編集</h1>
@include('commons.flash')

<form action="{{ route('orders.update', $order) }}" method="post">
    @csrf
    @method('put')
    <dl>
        <dt>顧客名</dt>
        <dd>
            <select name="customer_id" id="">
                @foreach ($customers as $customer)
                <!-- value 속성에 $customer->id 찾아온 후 드롭박스로 customers테이블에서 name 출력  -->
                <option value="{{ $customer->id }}">{{ $customer->name }} 様</option>
                @endforeach
            </select>
        </dd>
        <dt>商品を選択</dt>
        <dd>
            <select name="product_id" id="">
                @foreach($products as $product)
                <option value="{{ $product->id }}">{{ $product->name }}
                    ({{ $product->category->name }})
                </option>
                @endforeach
            </select>
        </dd>
        <dt>注文数</dt>
        <dd>
            <input type="number" name="quantity" value="" placeholder="数を入力" />個
        </dd>
        <dt>購入単価</dt>
        <dd>
            <input type="number" name="unit_price" value="" placeholder="数を入力" min="1" />円
        </dd>
        <dt>発送日</dt>
        <dd>
            <input type="date" name="shipped_on" value="" />
        </dd>
    </dl>
    <button type="submit">更新する</button>

</form>



@endsection

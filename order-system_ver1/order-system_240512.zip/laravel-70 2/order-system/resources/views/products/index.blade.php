@extends('layouts.app')

@section('content')
<h1>商品一覧</h1>
    <!-- Step3：상품검색 폼 -->
    <form action="{{ route('products.index') }}" method="get">
        <dl>
            <dt>カテゴリ</dt>
            <dd>
                <select name="category_id">
                    <option value=""></option>
                    @foreach($categories as $category)
                    <!-- 여기 코드 확인 할 것 -->
                    <option value="{{ $category->id }}" {{ request('category_id') == $category->id ? ' selected' : '' }}>
                        {{ $category->name }}（{{ $category->products->count()}}）
                    </option>
                    @endforeach
                </select>
            </dd>
            <dt>価格</dt>
            <dd>
                <input type="number" name="min_price" value="{{ request('min_price') }}" placeholder="円">
                ～
                <input type="number" name="max_price" value="{{ request('max_price') }}" placeholder="円">
            </dd>
            <dt>キーワード</dt>
            <dd><input type="text" name="keyword" value="{{ request('keyword') }}" placeholder="商品名"></dd>
        </dl>
        <button type="submit">検索</button>
    </form>

    <div>
        <!-- Step4옵션과제 : 가격집계 -->
        <div class="price-summary">
            最大：{{ $max_price }}円｜最小：{{ $min_price }}円｜平均：{{ $average_price }}円｜合計：{{ $total_price }}円
        </div>

        <!-- Step3：상품 일람 표시 -->
        <table>
            <thead>
                <th>ID</th><th>商品名</th><th>カテゴリ</th><th>価格</th>
            </thead>
            <tbody>
            @foreach($products as $product)
                <tr>
                    <td>{{ $product->id }}</td>
                    <td>{{ $product->name }}</td>
                    <td>{{ $product->category->name }}</td>
                    <td>{{ $product->price }}円</td>
                </tr>
            @endforeach
            </tbody>
        </table>
        {{ $products->appends(Request::all())->links() }}
    </div>
</body>
</html>
@endsection

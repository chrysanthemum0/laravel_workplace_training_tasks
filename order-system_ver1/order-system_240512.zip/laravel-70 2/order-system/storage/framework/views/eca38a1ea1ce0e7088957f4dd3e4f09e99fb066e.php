<?php $__env->startSection('content'); ?>
<h1>注文登録</h1>
<?php echo $__env->make('commons.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form action="<?php echo e(route('orders.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <dl>
        <dt>顧客名</dt>
        <dd>
            <select name="customer_id" id="">
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- value 속성에 $customer->id 찾아온 후 드롭박스로 customers테이블에서 name 출력  -->
                <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?> 様</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </dd>
        <dt>商品を選択</dt>
        <dd>
            <select name="product_id" id="">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?>

                    (<?php echo e($product->category->name); ?>)
                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </dd>
        <dt>注文数</dt>
        <dd>
            <input type="number" name="quantity" value="" placeholder="数を入力" />個
        </dd>
    </dl>
    <button type="submit">登録</button>

</form>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jinhongkim/Desktop/laravel-70/order-system/resources/views/orders/create.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name')); ?></title>
    <link rel="stylesheet" href="/main/style.css">
</head>
<body>
<header>
    <div class="container">
        <a class="brand" href="/"><?php echo e(config('app.name')); ?></a>
        <ul class="navigation">
            <li class="nav-products">
                <a href="<?php echo e(route('products.index')); ?>">商品管理</a>
            </li>
            <li class="nav-customers">
                <a href="<?php echo e(route('customers.index')); ?>">顧客管理</a>
            </li>
            <li class="nav-orders">
                <a href="<?php echo e(route('orders.index')); ?>">注文管理</a>
            </li>
        </ul>
    </div>
</header>
    <?php echo $__env->yieldContent('content'); ?>

    
</body>
</html>
<?php /**PATH /Users/jinhongkim/Desktop/laravel-70/order-system/resources/views/layouts/app.blade.php ENDPATH**/ ?>
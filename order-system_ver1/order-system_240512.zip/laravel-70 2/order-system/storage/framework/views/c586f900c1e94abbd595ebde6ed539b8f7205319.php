<?php $__env->startSection('content'); ?>
<h1>注文登録</h1>
<?php echo $__env->make('commons.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form action="<?php echo e(route('orders.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <dl>
        <dt>顧客名</dt>
        <dd>
            <select name="customer_id">
                <option value=""></option>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($customer->customer_id); ?>" <?php echo e(request('id') == $customer->id ? ' selected' : ''); ?> >
                    <?php echo e($customer->name); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </dd>
        <dt>商品を選択</dt>
        <dd>
            <select name="product_id">
                <option value=""></option>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($product->product_id); ?>" <?php echo e(request('id') == $product->id ? ' selected' : ''); ?>>
                    <?php echo e($product->name, $product->id); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </dd>
        <dt>注文数</dt>
        <dd>
            <input type="number" name="quntity" value="" size="5" placeholder="数を入力" />個
        </dd>
    </dl>
    <button type="submit">登録</button>

</form>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\student\Desktop\laravel-kadai\order-system\resources\views/orders/create.blade.php ENDPATH**/ ?>
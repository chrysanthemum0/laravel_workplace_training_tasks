<?php $__env->startSection('content'); ?>
<h1>商品一覧</h1>
    <!-- Step3：상품검색 폼 -->
    <form action="<?php echo e(route('products.index')); ?>" method="get">
        <dl>
            <dt>カテゴリ</dt>
            <dd>
                <select name="category_id">
                    <option value=""></option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- 여기 코드 확인 할 것 -->
                    <option value="<?php echo e($category->id); ?>" <?php echo e(request('category_id') == $category->id ? ' selected' : ''); ?>>
                        <?php echo e($category->name); ?>（<?php echo e($category->products->count()); ?>）
                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </dd>
            <dt>価格</dt>
            <dd>
                <input type="number" name="min_price" value="<?php echo e(request('min_price')); ?>" placeholder="円">
                ～
                <input type="number" name="max_price" value="<?php echo e(request('max_price')); ?>" placeholder="円">
            </dd>
            <dt>キーワード</dt>
            <dd><input type="text" name="keyword" value="<?php echo e(request('keyword')); ?>" placeholder="商品名"></dd>
        </dl>
        <button type="submit">検索</button>
    </form>

    <div>
        <!-- Step4옵션과제 : 가격집계 -->
        <div class="price-summary">
            最大：<?php echo e($max_price); ?>円｜最小：<?php echo e($min_price); ?>円｜平均：<?php echo e($average_price); ?>円｜合計：<?php echo e($total_price); ?>円
        </div>

        <!-- Step3：상품 일람 표시 -->
        <table>
            <thead>
                <th>ID</th><th>商品名</th><th>カテゴリ</th><th>価格</th>
            </thead>
            <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->id); ?></td>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->category->name); ?></td>
                    <td><?php echo e($product->price); ?>円</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($products->appends(Request::all())->links()); ?>

    </div>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\student\Desktop\laravel-kadai\order-system\resources\views/products/index.blade.php ENDPATH**/ ?>
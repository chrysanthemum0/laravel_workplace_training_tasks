<?php $__env->startSection('content'); ?>
<h1>注文詳細</h1>
<?php echo $__env->make('commons.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<table>
    <tr>
        <th>注文ID</th>
        <td><?php echo e($order->id); ?></td>
    </tr>
    <tr>
        <th>顧客</th>
        <td><?php echo e($order->customer->id); ?> : <?php echo e($order->customer->name); ?></td>
    </tr>
    <tr>
        <th>商品</th>
        <td><?php echo e($order->product->id); ?>: <?php echo e($order->product->name); ?></td>
    </tr>
    <tr>
        <th>注文数</th>
        <td><?php echo e($order->quantity); ?></td>
    </tr>
    <tr>
        <th>購入単価</th>
        <td><?php echo e($order->product->price); ?>円</td>
    </tr>
    <tr>
        <th>注文合計金額</th>
        <td><?php echo e($order->unit_price); ?>円</td>
    </tr>
    <tr>
        <th>注文日</th>
        <td><?php echo e($order->created_at); ?></td>
    <tr>
    </tr>
    <?php if(isset($order->shipped_on)): ?>
    <tr>
        <th>発送日</th>
        <td><?php echo e($order->shipped_on); ?></td>
    </tr>
    <?php else: ?>
    <tr>
        <th>発送日</th>
        <td>未発送</td>
    </tr>
<?php endif; ?>
</table>

<a href="<?php echo e(route('orders.edit', $order)); ?>">編集する</a>

<hr>
    <a href="#" onclick="deleteOrder()">注文を削除</a>
    <form action="<?php echo e(route('orders.destroy', $order)); ?>" method="post" id="delete-form" novalidate>
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
    </form>
    <script type="text/javascript">
        function deleteOrder() {
            event.preventDefault();
            if (window.confirm('本当に削除しますか？')) {
                document.getElementById('delete-form').submit();
            }
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jinhongkim/Desktop/laravel-70/order-system/resources/views/orders/show.blade.php ENDPATH**/ ?>
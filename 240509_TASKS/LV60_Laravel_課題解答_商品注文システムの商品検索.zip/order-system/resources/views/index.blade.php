<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{{ config('app.name') }}</title>
    <style>
        form {
            margin-bottom: 15px;
        }
        table {
            margin-bottom: 10px;
            border-collapse: collapse;
            border: 1px solid #ddd;
        }
        table th, table td {
            padding: 4px 8px;
            border: 1px solid #ddd;
        }
        table th {
            background: #eee;
        }
        svg.w-5.h-5 {
            width: 25px;
            vertical-align: middle;
        }
        .price-summary {
            margin-bottom: 10px;
            padding: 5px;
            background: #ddf;
        }
    </style>
</head>
<body>
    <!-- Step3：商品検索フォーム -->
    <form action="{{ route('products.index') }}" method="get">
        <dl>
            <dt>カテゴリ</dt>
            <dd>
                <select name="category_id">
                    <option value=""></option>
                    @foreach($categories as $category)
                    <option value="{{ $category->id }}"{{ request('category_id') == $category->id ? ' selected' : '' }}>{{ $category->name }}（{{ $category->products->count()}}）</option>
                    @endforeach
                </select>
            </dd>
            <dt>価格</dt>
            <dd>
                <input type="number" name="min_price" value="{{ request('min_price') }}" placeholder="円">
                ～
                <input type="number" name="max_price" value="{{ request('max_price') }}" placeholder="円">                
            </dd>
            <dt>キーワード</dt>
            <dd><input type="text" name="keyword" value="{{ request('keyword') }}" placeholder="商品名"></dd>
        </dl>
        <button type="submit">検索</button>
    </form>

    <div>
        <!-- Step4オプション課題：価格集計 -->
        <div class="price-summary">
            最大：{{ $max_price }}円｜最小：{{ $min_price }}円｜平均：{{ $average_price }}円｜合計：{{ $total_price }}円
        </div>

        <!-- Step3：商品一覧表示 -->
        <table>
            <thead>
                <th>ID</th><th>商品名</th><th>カテゴリ</th><th>価格</th>
            </thead>
            <tbody>
            @foreach($products as $product)
                <tr>
                    <td>{{ $product->id }}</td>
                    <td>{{ $product->name }}</td>
                    <td>{{ $product->category->name }}</td>
                    <td>{{ $product->price }}円</td>
                </tr>
            @endforeach
            </tbody>
        </table>
        {{ $products->appends(Request::all())->links() }}
    </div>
</body>
</html>
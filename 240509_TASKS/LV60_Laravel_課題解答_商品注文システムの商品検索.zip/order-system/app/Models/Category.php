<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;

    // Step1：created_atカラムとupdated_atカラムを無効に
    const CREATED_AT = null;
    const UPDATED_AT = null;

    // Step1：Productとのリレーション
    public function products()
    {
        return $this->hasMany(Product::class);
    }
}

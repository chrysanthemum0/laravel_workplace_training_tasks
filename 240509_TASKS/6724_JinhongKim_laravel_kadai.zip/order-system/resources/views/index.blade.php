<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name') }}</title>
    <link rel="stylesheet" href="/main/style.css">
</head>
<body>
    <form action="{{ route('index') }}" method="get">
        @include('search')
        <button type="submit">検索</button>
    </form>

    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>商品名</th>
                <th>カテゴリ</th>
                <th>価格</th>
            </tr>
        </thead>
        <tbody>
        @foreach ($products as $product)
            <tr>
                <td>{{ $product->id }}</td>
                <td>{{ $product->name }}</td>
                <td>{{ $product->category->name }}</td>
                <td>{{ $product->price }} 円</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    {{ $products->appends(Request::all())->links() }}
</body>
</html>

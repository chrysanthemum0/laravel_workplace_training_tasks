<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name') }}</title>
    <a href="/">{{ config('app.name') }}</a>
    @include('nav')
</head>
<body>
    <h1>顧客管理</h1>
    <table>
        <thead>
            <tr>
                <th>顧客ID</th><th>顧客名</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($customers as $customer)
                <tr>
                    <td>{{ $customer->id }}</td>
                    <td>{{ $customer->name }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>

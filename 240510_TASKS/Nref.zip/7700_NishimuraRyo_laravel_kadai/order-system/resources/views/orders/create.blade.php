<!-- 注文登録画面 -->
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name')}}</title>
</head>
<body>
    @include('flash')
    <form action="{{ route('orders.store') }}" method="post" novalidate>
        @csrf
        <!-- 顧客 -->
        <dl>
            <dt>顧客名</dt>
            <dd>
                <select name="customer_id" id="">
                @foreach ($customers as $customer)
                    <option value="{{ $customer->id }}">{{ $customer->name }} 様</option>
                @endforeach
                </select>
            </dd>
        <!-- products -->
            <dt>商品名</dt>
            <dd>
                <select name="product_id" id="">
                @foreach ($products as $product)
                    <option value="{{ $product->id }}">{{ $product->name}} ( {{ $product->category->name }} ) </option>
                @endforeach
                </select>
            </dd>
            <dt>注文数</dt>
            <dd>
                <input type="number" name="quantity" min="1" max="999">個
            </dd>
        </dl>
        <button type="submit">登録する</button>
    </form>
</body>
</html>

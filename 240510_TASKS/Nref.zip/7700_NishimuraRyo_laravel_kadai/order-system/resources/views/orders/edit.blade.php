<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name') }}</title>
    <a href="/">{{ config('app.name') }}</a>
    @include('nav')
</head>
<body>
    <h1>注文編集</h1>
    @include('flash')
    <form action="{{ route('orders.update', $order) }}" method="post" novalidate>
    @csrf
    @method('put')
        <dl>
            <dt>顧客名</dt>
            <dd>
                <select name="customer_id" id="">
                    @foreach ($customers as $customer)
                        <option value="{{ $customer->id }}">{{ $customer->name }} 様</option>
                    @endforeach
                </select>
            </dd>
            <dt>商品名</dt>
            <dd>
                <select name="product_id" id="">
                @foreach ($products as $product)
                    <option value="{{ $product->id }}">{{ $product->name}} ( {{ $product->category->name }} ) </option>
                @endforeach
                </select>
            </dd>
            <dt>注文数</dt>
            <dd>
                <input type="number" name="quantity" min="1" max="999">個
            </dd>
            <dt>購入単価</dt>
            <dd>
                <input type="number" name="unit_price" min="1">円
            </dd>
            <dt>発送日</dt>
            <dd>
                <input type="date" name="shipped_on">
            </dd>
        </dl>
        <button type="submit">更新する</button>
        <a href="{{ route('orders.show', $order->id) }}">キャンセル</a>
    </form>
</body>
</html>

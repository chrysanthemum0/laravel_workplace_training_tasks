<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name') }}</title>
    <a href="/">{{ config('app.name') }}</a>
    @include('nav')
</head>
<body>
    <h1>注文詳細</h1>
    <table>
        <tr>
            <th>注文ID</th>
            <td>{{ $order->id }}</td>
        </tr>
        <tr>
            <th>顧客</th>
            <td>{{ $order->customer->id }} : {{ $order->customer->name }} 様</td>
        </tr>
        <tr>
            <th>商品</th>
            <td>{{ $order->product->id }} : {{ $order->product->name }} ( {{ $order->product->category->name }} )</td>
        </tr>
        <tr>
            <th>注文数</th>
            <td>{{ $order->quantity }}</td>
        </tr>
        <tr>
            <th>購入単価</th>
            <td>{{ $order->unit_price }}</td>
        </tr>
        <tr>
            <th>注文合計金額</th>
            <td>{{ $order->quantity * $order->unit_price }}</td>
        </tr>
        <tr>
            <th>注文日</th>
            <td>{{ $order->created_at }}</td>
        </tr>
        @include('delivery')
    </table>
    <a href="{{ route('orders.edit', $order) }}">編集</a>
    <hr>
    <a href="#" onclick="deleteOrder()">注文を削除</a>
    <form action="{{ route('orders.destroy', $order) }}" method="post" id="delete-form" novalidate>
        @csrf
        @method('delete')
    </form>
    <script type="text/javascript">
        function deleteOrder() {
            event.preventDefault();
            if (window.confirm('本当に削除しますか？')) {
                document.getElementById('delete-form').submit();
            }
        }
    </script>
</body>
</html>

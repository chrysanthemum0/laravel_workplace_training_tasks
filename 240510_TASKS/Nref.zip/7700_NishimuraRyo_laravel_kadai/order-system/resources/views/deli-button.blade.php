@if ($order->shipped_at)
    <td>{{ $order->shipped_at }}</td>
@else
    <td>
        <form action="" method="post" novalidate>
            @csrf
            <button type="submit">発送済みにする</button>
        </form>
    </td>
@endif

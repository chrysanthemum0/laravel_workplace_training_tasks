@if (isset($order->shipped_on))
    <tr>
        <th>発送日</th>
        <td>{{ $order->shipped_on }}</td>
    </tr>
@else
    <tr>
        <th>発送日</th>
        <td>未発送</td>
    </tr>
@endif

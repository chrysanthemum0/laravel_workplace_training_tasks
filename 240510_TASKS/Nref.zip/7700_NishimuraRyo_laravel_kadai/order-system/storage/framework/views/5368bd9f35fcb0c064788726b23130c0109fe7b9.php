<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name')); ?></title>
    <a href="/"><?php echo e(config('app.name')); ?></a>
    <?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <h1>注文管理</h1>
    <a href="<?php echo e(route('orders.create')); ?>">新規注文作成</a>
    <table>
        <thead>
            <th>詳細</th>
            <th>注文ID</th>
            <th>注文日</th>
            <th>顧客名</th>
            <th>商品名</th>
            <th>注文数</th>
            <th>注文合計金額</th>
            <th>発送日</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a href="<?php echo e(route('orders.show', $order->id)); ?>">詳細</a></td>
                    <td><?php echo e($order->id); ?></td>
                    <td><?php echo e($order->created_at); ?></td>
                    <td><?php echo e($order->customer->name); ?></td>
                    <td><?php echo e($order->product->name); ?></td>
                    <td><?php echo e($order->quantity); ?></td>
                    <td><?php echo e($order->quantity * $order->unit_price); ?></td>
                    <?php echo $__env->make('deli-button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\student\Desktop\laravel-kadai\order-system\resources\views/orders/index.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo e(config('app.name')); ?></title>
    <a href="/"><?php echo e(config('app.name')); ?></a>
    <?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        form {
            margin-bottom: 15px;
        }
        table {
            margin-bottom: 10px;
            border-collapse: collapse;
            border: 1px solid #ddd;
        }
        table th, table td {
            padding: 4px 8px;
            border: 1px solid #ddd;
        }
        table th {
            background: #eee;
        }
        svg.w-5.h-5 {
            width: 25px;
            vertical-align: middle;
        }
        .price-summary {
            margin-bottom: 10px;
            padding: 5px;
            background: #ddf;
        }
    </style>
</head>
<body>
    <!-- Step3：商品検索フォーム -->
    <form action="<?php echo e(route('products.index')); ?>" method="get">
        <dl>
            <dt>カテゴリ</dt>
            <dd>
                <select name="category_id">
                    <option value=""></option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"<?php echo e(request('category_id') == $category->id ? ' selected' : ''); ?>><?php echo e($category->name); ?>（<?php echo e($category->products->count()); ?>）</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </dd>
            <dt>価格</dt>
            <dd>
                <input type="number" name="min_price" value="<?php echo e(request('min_price')); ?>" placeholder="円">
                ～
                <input type="number" name="max_price" value="<?php echo e(request('max_price')); ?>" placeholder="円">
            </dd>
            <dt>キーワード</dt>
            <dd><input type="text" name="keyword" value="<?php echo e(request('keyword')); ?>" placeholder="商品名"></dd>
        </dl>
        <button type="submit">検索</button>
    </form>

    <div>
        <!-- Step4オプション課題：価格集計 -->
        <div class="price-summary">
            最大：<?php echo e($max_price); ?>円｜最小：<?php echo e($min_price); ?>円｜平均：<?php echo e($average_price); ?>円｜合計：<?php echo e($total_price); ?>円
        </div>

        <!-- Step3：商品一覧表示 -->
        <table>
            <thead>
                <th>ID</th><th>商品名</th><th>カテゴリ</th><th>価格</th>
            </thead>
            <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->id); ?></td>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->category->name); ?></td>
                    <td><?php echo e($product->price); ?>円</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($products->appends(Request::all())->links()); ?>

    </div>
</body>
</html>
<?php /**PATH C:\Users\student\Desktop\laravel-kadai\order-system\resources\views/index.blade.php ENDPATH**/ ?>
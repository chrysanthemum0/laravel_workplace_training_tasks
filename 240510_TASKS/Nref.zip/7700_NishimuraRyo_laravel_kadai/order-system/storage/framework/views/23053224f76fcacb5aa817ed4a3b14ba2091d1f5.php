<?php if(isset($order->shipped_on)): ?>
    <tr>
        <th>発送日</th>
        <td><?php echo e($order->shipped_on); ?></td>
    </tr>
<?php else: ?>
    <tr>
        <th>発送日</th>
        <td>未発送</td>
    </tr>
<?php endif; ?>
<?php /**PATH C:\Users\student\Desktop\laravel-kadai\order-system\resources\views/delivery.blade.php ENDPATH**/ ?>
<ul>
    <li>
        <a href="<?php echo e(route('products.index')); ?>">商品管理</a>
    </li>
    <li>
        <a href="<?php echo e(route('customers.index')); ?>">顧客管理</a>
    </li>
    <li>
        <a href="<?php echo e(route('orders.index')); ?>">注文管理</a>
    </li>
</ul>
<?php /**PATH C:\Users\student\Desktop\laravel-kadai\order-system\resources\views/nav.blade.php ENDPATH**/ ?>
<!-- 注文登録画面 -->
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name')); ?></title>
</head>
<body>
    <?php echo $__env->make('flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="<?php echo e(route('orders.store')); ?>" method="post" novalidate>
        <?php echo csrf_field(); ?>
        <!-- 顧客 -->
        <dl>
            <dt>顧客名</dt>
            <dd>
                <select name="customer_id" id="">
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?> 様</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </dd>
        <!-- products -->
            <dt>商品名</dt>
            <dd>
                <select name="product_id" id="">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?> ( <?php echo e($product->category->name); ?> ) </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </dd>
            <dt>注文数</dt>
            <dd>
                <input type="number" name="quantity" min="1" max="999">個
            </dd>
        </dl>
        <button type="submit">登録する</button>
    </form>
</body>
</html>
<?php /**PATH C:\Users\student\Desktop\laravel-kadai\order-system\resources\views/orders/create.blade.php ENDPATH**/ ?>
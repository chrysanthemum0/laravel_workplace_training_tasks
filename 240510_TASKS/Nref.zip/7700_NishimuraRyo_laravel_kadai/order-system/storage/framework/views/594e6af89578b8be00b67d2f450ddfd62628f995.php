<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name')); ?></title>
    <a href="/"><?php echo e(config('app.name')); ?></a>
    <?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <h1>注文編集</h1>
    <?php echo $__env->make('flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="<?php echo e(route('orders.update', $order)); ?>" method="post" novalidate>
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
        <dl>
            <dt>顧客名</dt>
            <dd>
                <select name="customer_id" id="">
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?> 様</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </dd>
            <dt>商品名</dt>
            <dd>
                <select name="product_id" id="">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?> ( <?php echo e($product->category->name); ?> ) </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </dd>
            <dt>注文数</dt>
            <dd>
                <input type="number" name="quantity" min="1" max="999">個
            </dd>
            <dt>購入単価</dt>
            <dd>
                <input type="number" name="unit_price" min="1">円
            </dd>
            <dt>発送日</dt>
            <dd>
                <input type="date" name="shipped_on">
            </dd>
        </dl>
        <button type="submit">更新する</button>
        <a href="<?php echo e(route('orders.show', $order->id)); ?>">キャンセル</a>
    </form>
</body>
</html>
<?php /**PATH C:\Users\student\Desktop\laravel-kadai\order-system\resources\views/orders/edit.blade.php ENDPATH**/ ?>
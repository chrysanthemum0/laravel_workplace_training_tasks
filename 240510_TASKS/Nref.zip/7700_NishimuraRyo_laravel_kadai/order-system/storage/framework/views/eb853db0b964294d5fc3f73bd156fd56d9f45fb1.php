<?php if($order->shipped_at): ?>
    <td><?php echo e($order->shipped_at); ?></td>
<?php else: ?>
    <td>
        <form action="" method="post" novalidate>
            <button type="submit">発送済みにする</button>
        </form>
    </td>
<?php endif; ?>
<?php /**PATH C:\Users\student\Desktop\laravel-kadai\order-system\resources\views/deli-button.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name')); ?></title>
    <a href="/"><?php echo e(config('app.name')); ?></a>
    <?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <h1>注文詳細</h1>
    <table>
        <tr>
            <th>注文ID</th>
            <td><?php echo e($order->id); ?></td>
        </tr>
        <tr>
            <th>顧客</th>
            <td><?php echo e($order->customer->id); ?> : <?php echo e($order->customer->name); ?> 様</td>
        </tr>
        <tr>
            <th>商品</th>
            <td><?php echo e($order->product->id); ?> : <?php echo e($order->product->name); ?> ( <?php echo e($order->product->category->name); ?> )</td>
        </tr>
        <tr>
            <th>注文数</th>
            <td><?php echo e($order->quantity); ?></td>
        </tr>
        <tr>
            <th>購入単価</th>
            <td><?php echo e($order->unit_price); ?></td>
        </tr>
        <tr>
            <th>注文合計金額</th>
            <td><?php echo e($order->quantity * $order->unit_price); ?></td>
        </tr>
        <tr>
            <th>注文日</th>
            <td><?php echo e($order->created_at); ?></td>
        </tr>
        <?php echo $__env->make('delivery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </table>
    <a href="<?php echo e(route('orders.edit', $order)); ?>">編集</a>
    <hr>
    <a href="#" onclick="deleteOrder()">注文を削除</a>
    <form action="<?php echo e(route('orders.destroy', $order)); ?>" method="post" id="delete-form" novalidate>
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
    </form>
    <script type="text/javascript">
        function deleteOrder() {
            event.preventDefault();
            if (window.confirm('本当に削除しますか？')) {
                document.getElementById('delete-form').submit();
            }
        }
    </script>
</body>
</html>
<?php /**PATH C:\Users\student\Desktop\laravel-kadai\order-system\resources\views/orders/show.blade.php ENDPATH**/ ?>
@extends('layouts.app')

@section('content')
<h1>注文管理</h1>
    <a href="{{ route('orders.create') }}">新規注文作成</a>

    <table>
        <thead>
            <tr>
                <th>詳細</th>
                <th>注文ID</th>
                <th>注文日</th>
                <th>顧客名</th>
                <th>商品名</th>
                <th>注文数</th>
                <th>注文合計金額</th>
                <th>発送日</th>
            </tr>
        </thead>
        <tbody>
            @foreach($orders as $order)
            <tr>
                <td>
                    <a href="{{ route('orders.show', $order->id) }}">
                        詳細
                    </a>
                </td>
                <td>{{ $order->customer_id }}</td>
                <td>{{ $order->created_at }}</td>
                <td>{{ $order->customer->name }}</td>
                <td>{{ $order->product->name }}</td>
                <td>{{ $order->quantity }}</td>
                <td>{{ $order->unit_price }}円</td>
                <td>{{ $order->shipped_on }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>


@endsection

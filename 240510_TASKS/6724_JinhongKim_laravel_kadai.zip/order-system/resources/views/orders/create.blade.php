@extends('layouts.app')

@section('content')
<h1>注文登録</h1>
@include('commons.flash')

<form action="{{ route('orders.store') }}" method="post">
    @csrf
    <dl>
        <dt>顧客名</dt>
        <dd>
            <select name="customer_id">
                <option value=""></option>
                @foreach($customers as $customer)
                <option value="{{ $customer->customer_id }}" {{ request('id') == $customer->id ? ' selected' : '' }} >
                    {{ $customer->name }}
                </option>
                @endforeach
            </select>
        </dd>
        <dt>商品を選択</dt>
        <dd>
            <select name="product_id">
                <option value=""></option>
                @foreach($products as $product)
                <option value="{{$product->product_id}}" {{ request('id') == $product->id ? ' selected' : '' }}>
                    {{ $product->name, $product->id }}
                </option>
                @endforeach
            </select>
        </dd>
        <dt>注文数</dt>
        <dd>
            <input type="number" name="quntity" value="" size="5" placeholder="数を入力" />個
        </dd>
    </dl>
    <button type="submit">登録</button>

</form>
</body>
</html>
@endsection

@extends('layouts.app')

@section('content')
<h1>注文詳細</h1>
@include('commons.flash')


@endsection

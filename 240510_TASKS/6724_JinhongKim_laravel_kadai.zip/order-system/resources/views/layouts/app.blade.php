<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name') }}</title>
    <link rel="stylesheet" href="/main/style.css">
</head>
<body>
<header>
    <div class="container">
        <a class="brand" href="/">{{ config('app.name') }}</a>
        <ul class="navigation">
            <li class="nav-products">
                <a href="{{ route('products.index') }}">商品管理</a>
            </li>
            <li class="nav-customers">
                <a href="{{ route('customers.index') }}">顧客管理</a>
            </li>
            <li class="nav-orders">
                <a href="{{ route('orders.index') }}">注文管理</a>
            </li>
        </ul>
    </div>
</header>
    @yield('content')

    
</body>
</html>

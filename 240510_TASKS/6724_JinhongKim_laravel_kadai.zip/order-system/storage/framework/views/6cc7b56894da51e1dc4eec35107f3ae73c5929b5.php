<div>
<p>カテゴリ</p>
        <select name="category_list" id="">
            <option value=""></option>
        </select>
</div>

<div>
    <p>価格</p>
        <input type="number" name="" placeholder="円">
        ～
        <input type="number" name="" placeholder="円">
</div>

<div>
    <p>キーワード</p>
    <input type="text" name="" placeholder="商品名">
</div>
<br>
<?php /**PATH C:\Users\student\Desktop\laravel-kadai\order-system\resources\views/search.blade.php ENDPATH**/ ?>
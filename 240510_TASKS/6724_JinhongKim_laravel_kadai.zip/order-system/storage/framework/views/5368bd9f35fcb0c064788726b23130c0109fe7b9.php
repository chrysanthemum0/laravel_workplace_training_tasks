<?php $__env->startSection('content'); ?>
<h1>注文管理</h1>
    <a href="<?php echo e(route('orders.create')); ?>">新規注文作成</a>

    <table>
        <thead>
            <tr>
                <th>詳細</th>
                <th>注文ID</th>
                <th>注文日</th>
                <th>顧客名</th>
                <th>商品名</th>
                <th>注文数</th>
                <th>注文合計金額</th>
                <th>発送日</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <a href="<?php echo e(route('orders.show', $order->id)); ?>">
                        詳細
                    </a>
                </td>
                <td><?php echo e($order->customer_id); ?></td>
                <td><?php echo e($order->created_at); ?></td>
                <td><?php echo e($order->customer->name); ?></td>
                <td><?php echo e($order->product->name); ?></td>
                <td><?php echo e($order->quantity); ?></td>
                <td><?php echo e($order->unit_price); ?>円</td>
                <td><?php echo e($order->shipped_on); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\student\Desktop\laravel-kadai\order-system\resources\views/orders/index.blade.php ENDPATH**/ ?>
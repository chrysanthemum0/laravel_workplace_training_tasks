

<?php $__env->startSection('content'); ?>
<h1>注文管理</h1>
<p><a href="<?php echo e(route('orders.create')); ?>">新規注文作成</a></p>
<table class="table">
    <thead>
        <th>詳細</th><th>注文ID</th><th>注文日</th><th>顧客名</th><th>商品名</th><th>注文数</th><th>注文合計金額</th><th>発送日</th>
    </thead>
    <tbody>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><a href="<?php echo e(route('orders.show', $order->id)); ?>">詳細</a></td>
            <td><?php echo e($order->id); ?></td>
            <td><?php echo e($order->created_at->format('Y年m月d日')); ?></td>
            <td><?php echo e($order->customer->name); ?></td> 
            <td><?php echo e($order->product->name); ?></td>
            <td><?php echo e($order->quantity); ?></td>
            <td><?php echo e($order->quantity * $order->unit_price); ?>円</td>
            <td>
                <?php if($order->shipped_on): ?>
                <?php echo e($order->shipped_on); ?>

                <?php else: ?>
                <form onsubmit="return confirm('発送済みにしますか？')" action="<?php echo e(route('orders.ship', $order->id)); ?>" method="post">
                    <?php echo csrf_field(); ?> 
                    <?php echo method_field('patch'); ?>
                    <button type="submit">発送済みにする</button>
                </form>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\laravel-kadai\lv70\order-system\resources\views/orders/index.blade.php ENDPATH**/ ?>
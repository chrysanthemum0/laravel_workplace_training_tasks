<dl>
    <dt>顧客名</dt>
    <dd>
        <select name="customer_id">
            <option value=""></option>
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($customer->id); ?>"<?php echo e(old('customer_id', $order->customer_id) == $customer->id ? ' selected' : ''); ?>>
                <?php echo e($customer->name); ?> 様
            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </dd>
    <dt>商品を選択</dt>
    <dd>
        <select name="product_id">
            <option value=""></option>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($product->id); ?>"<?php echo e(old('product_id', $order->product_id) == $product->id ? ' selected' : ''); ?>>
                <?php echo e($product->name); ?>（<?php echo e($product->category->name); ?>）
            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </dd>
    <dt>注文数</dt>
    <dd><input type="number" name="quantity" min="1" max="999" value="<?php echo e(old('quantity', $order->quantity)); ?>"> 個</dd>
    <?php if($order->id): ?>
    <dt>購入単価</dt>
    <dd><input type="number" name="unit_price" min="1" value="<?php echo e(old('unit_price', $order->unit_price)); ?>"> 円</dd>
    <dt>発送日</dt>
    <dd><input type="date" name="shipped_on" value="<?php echo e(old('shipped_on', $order->shipped_on)); ?>"></dd>
    <?php endif; ?>
</dl><?php /**PATH C:\Users\USER\Desktop\laravel-kadai\lv70\order-system\resources\views/orders/form.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('commons.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>注文登録</h1>

    <form action="<?php echo e(route('orders.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <p>
            <label>顧客名</label><br>
            <select name="customer_id" id="category_id">
                <option value="">選択なし</option>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($customer->id); ?>">
                        <?php echo e($customer->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </p>
        <p>
            <label>商品を選択</label><br>
            <select name="product_id" id="category_id">
                <option value="">選択なし</option>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product->id); ?>">
                        <?php echo e($product->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </p>
        <p>
            <label>注文数</label><br>
            <input type="number" name="quantity">個
        </p>
        <a href="<?php echo e(route('orders.index')); ?>">キャンセル</a>
        <button type="submit">登録する</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\student\Desktop\laravel-kadai\order-system\resources\views/orders/create.blade.php ENDPATH**/ ?>
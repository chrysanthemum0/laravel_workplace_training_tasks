<?php $__env->startSection('content'); ?>
    <section>
        <form action="/" method="get" id="search_form" name="form1">
            <p>
                <label>カテゴリ</label><br>
                <select name="category_id" id="category_id">
                    <option value="">選択なし</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if(Request::input('category_id') == $category->id): ?> selected <?php endif; ?> value="<?php echo e($category->id); ?>">
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </p>
            <p>
                <label>価格</label><br>
                <input type="number" name="price_min" placeholder="円" value="<?php echo e(Request::input('price_min')); ?>">
                ～
                <input type="number" name="price_max" placeholder="円" value="<?php echo e(Request::input('price_max')); ?>">
            </p>
            <p>
                <label>キーワード</label><br>
                <input type="text" name="name" placeholder="キーワード" value="<?php echo e(Request::input('name')); ?>">
            </p>
            <button type="reset" onclick="form_reset()">リセット</button>
            <button type="submit">検索</button>
        </form>
        <script>
            function form_reset() {
                var el = document.getElementById('category_id');
                console.log(el);
                console.log(document.form1.category_id.selectedIndex);
                for (const option of el.options) {
                    option.selected = false
                    console.log(option.selected);
                }
                el.options[0].selected = true;
                el.selectedIndex = 4;
                document.form1.price_min.defaultValue = "";
                document.form1.price_max.defaultValue = "";
                document.form1.name.defaultValue = "";
            }
        </script>
    </section>
    <section>
        <p style="background-color: #3092a605">
            最大：<?php echo e($whole_prices['max']); ?>円｜

            最小：<?php echo e($whole_prices['min']); ?>円｜

            平均：<?php echo e($whole_prices['avg']); ?>円｜

            合計：<?php echo e($whole_prices['sum']); ?>円
        </p>
        <table class="table">
            <tr>
                <th>ID</th>
                <th>商品名</th>
                <th>カテゴリ</th>
                <th>価格</th>
            </tr>
            
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->id); ?></td>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->category->name); ?></td>
                    <td><?php echo e($product->price); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <p>
            
            <?php echo e($products->appends(Request::all())->links()); ?>



        </p>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\student\Desktop\laravel-kadai\order-system\resources\views/home/index.blade.php ENDPATH**/ ?>
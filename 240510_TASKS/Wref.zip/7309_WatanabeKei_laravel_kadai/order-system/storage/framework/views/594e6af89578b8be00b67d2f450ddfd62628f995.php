<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('commons.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>注文編集</h1>

    <form action="<?php echo e(route('orders.update', $orders[0]->order_id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>
        <p>
            <label>顧客名</label><br>
            <select name="customer_id" id="category_id">
                <option value="">選択なし</option>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php if($orders[0]->customer_id == $customer->id): ?> selected <?php endif; ?> value="<?php echo e($customer->id); ?>">
                        <?php echo e($customer->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </p>
        <p>
            <label>商品を選択</label><br>
            <select name="product_id" id="category_id">
                <option value="">選択なし</option>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php if($orders[0]->customer_id == $product->id): ?> selected <?php endif; ?> value="<?php echo e($product->id); ?>">
                        <?php echo e($product->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </p>
        <p>
            <label>注文数</label><br>
            <input type="number" name="quantity" value="<?php echo e($orders[0]->quantity); ?>">個
        </p>
        <p>
            <label>発送日</label><br>
            <input type="date" name="shipped_on">
        </p>
        <a href="<?php echo e(route('orders.index')); ?>">キャンセル</a>
        <button type="submit">検索</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\student\Desktop\laravel-kadai\order-system\resources\views/orders/edit.blade.php ENDPATH**/ ?>
@extends('layouts.app')

@section('content')
    @include('commons.flash')
    <h1>注文編集</h1>

    <form action="{{ route('orders.update', $orders[0]->order_id) }}" method="post">
        @csrf
        @method('patch')
        <p>
            <label>顧客名</label><br>
            <select name="customer_id" id="category_id">
                <option value="">選択なし</option>
                @foreach ($customers as $customer)
                    <option @if ($orders[0]->customer_id == $customer->id) selected @endif value="{{ $customer->id }}">
                        {{ $customer->name }}
                    </option>
                @endforeach
            </select>
        </p>
        <p>
            <label>商品を選択</label><br>
            <select name="product_id" id="category_id">
                <option value="">選択なし</option>
                @foreach ($products as $product)
                    <option @if ($orders[0]->customer_id == $product->id) selected @endif value="{{ $product->id }}">
                        {{ $product->name }}
                    </option>
                @endforeach
            </select>
        </p>
        <p>
            <label>注文数</label><br>
            <input type="number" name="quantity" value="{{ $orders[0]->quantity }}">個
        </p>
        <p>
            <label>発送日</label><br>
            <input type="date" name="shipped_on">
        </p>
        <a href="{{ route('orders.index') }}">キャンセル</a>
        <button type="submit">検索</button>
    </form>
@endsection

@extends('layouts.app')

@section('content')
    <h1>注文管理</h1>
    <a href="{{ route('orders.create') }}">新規注文作成</a>
    <table class="table">
        <tr>
            <th>詳細</th>
            <th>注文ID</th>
            <th>注文日</th>
            <th>顧客名</th>
            <th>商品名</th>
            <th>注文数</th>
            <th>注文合計金額</th>
            <th>発送日</th>

        </tr>
        @foreach ($orders as $order)
            <tr>
                <td><a href="{{ route('orders.show', $order->order_id) }}">詳細</a></td>
                <td>{{ $order->order_id }}</td>
                <td>{{ $order->order_date }}</td>
                <td>{{ $order->name }}</td>
                <td>{{ $order->product_name }}</td>
                <td>{{ $order->quantity }}</td>
                <td>{{ $order->unit_price }}円</td>
                <td>
                    @if ($order->shipped_on == null)
                        <form action="{{ route('orders.ship', $order->order_id) }}" method="post" id="ship_form">
                            @csrf
                            @method('patch')
                            <button type="submit" onclick="clicks()">発送済みにする</button>
                        </form>
                    @else
                        {{ $order->shipped_on }}
                    @endif
                </td>
            </tr>
        @endforeach
    </table>
    <script>
        const clicks = () => {
            event.preventDefault();
            if (window.confirm('発送済み')) {
                document.getElementById('ship_form').submit();
            }
        }
    </script>
@endsection

@extends('layouts.app')

@section('content')
    @include('commons.flash')
    <h1>注文登録</h1>

    <form action="{{ route('orders.store') }}" method="post">
        @csrf
        <p>
            <label>顧客名</label><br>
            <select name="customer_id" id="category_id">
                <option value="">選択なし</option>
                @foreach ($customers as $customer)
                    <option value="{{ $customer->id }}">
                        {{ $customer->name }}
                    </option>
                @endforeach
            </select>
        </p>
        <p>
            <label>商品を選択</label><br>
            <select name="product_id" id="category_id">
                <option value="">選択なし</option>
                @foreach ($products as $product)
                    <option value="{{ $product->id }}">
                        {{ $product->name }}
                    </option>
                @endforeach
            </select>
        </p>
        <p>
            <label>注文数</label><br>
            <input type="number" name="quantity">個
        </p>
        <a href="{{ route('orders.index') }}">キャンセル</a>
        <button type="submit">登録する</button>
    </form>
@endsection

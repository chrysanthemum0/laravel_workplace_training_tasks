@extends('layouts.app')

@section('content')
    <h1>注文管理</h1>
    <table class="table">

        <tr>
            <th>注文ID</th>
            <td>{{ $orders[0]->order_id }}</td>
        </tr>
        <tr>
            <th>注文日</th>
            <td>{{ $orders[0]->order_date }}</td>
        </tr>
        <tr>
            <th>顧客名</th>
            <td>{{ $orders[0]->name }}</td>
        </tr>
        <tr>
            <th>商品名</th>
            <td>{{ $orders[0]->product_name }}</td>
        </tr>
        <tr>
            <th>注文数</th>
            <td>{{ $orders[0]->quantity }}</td>
        </tr>
        <tr>
            <th>購入単価</th>
            <td>{{ $orders[0]->price }}円</td>
        </tr>
        <tr>
            <th>注文合計金額</th>
            <td>{{ $orders[0]->unit_price }}円</td>
        </tr>
        <tr>
            <th>発送日</th>
            <td>{{ $orders[0]->shipped_on == null ? '未発送' : $orders[0]->shipped_on }}</td>
        </tr>
        <tr>
            <th>編集</th>
            <td><a href="{{ route('orders.edit', $orders[0]->order_id) }}">編集</a></td>
        </tr>
    </table>
    <form action="{{ route('orders.destroy', $orders[0]->order_id) }}" method="post" id="delete_form">
        @csrf
        @method('delete')
        <button type="button" onclick="btn_delete()">削除する</button>
    </form>
    <script>
        const form = document.getElementById('delete_form');

        function btn_delete() {
            if (confirm('本当に削除しますか')) {
                form.submit();
            }
        }
    </script>
@endsection

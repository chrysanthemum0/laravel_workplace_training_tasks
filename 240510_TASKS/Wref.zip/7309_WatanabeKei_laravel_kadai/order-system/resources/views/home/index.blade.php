@extends('layouts.app')

@section('content')
    <section>
        <form action="/" method="get" id="search_form" name="form1">
            <p>
                <label>カテゴリ</label><br>
                <select name="category_id" id="category_id">
                    <option value="">選択なし</option>
                    @foreach ($categories as $category)
                        <option @if (Request::input('category_id') == $category->id) selected @endif value="{{ $category->id }}">
                            {{ $category->name }}
                        </option>
                    @endforeach
                </select>
            </p>
            <p>
                <label>価格</label><br>
                <input type="number" name="price_min" placeholder="円" value="{{ Request::input('price_min') }}">
                ～
                <input type="number" name="price_max" placeholder="円" value="{{ Request::input('price_max') }}">
            </p>
            <p>
                <label>キーワード</label><br>
                <input type="text" name="name" placeholder="キーワード" value="{{ Request::input('name') }}">
            </p>
            <button type="reset" onclick="form_reset()">リセット</button>
            <button type="submit">検索</button>
        </form>
        <script>
            function form_reset() {
                var el = document.getElementById('category_id');
                console.log(el);
                console.log(document.form1.category_id.selectedIndex);
                for (const option of el.options) {
                    option.selected = false
                    console.log(option.selected);
                }
                el.options[0].selected = true;
                el.selectedIndex = 4;
                document.form1.price_min.defaultValue = "";
                document.form1.price_max.defaultValue = "";
                document.form1.name.defaultValue = "";
            }
        </script>
    </section>
    <section>
        <p style="background-color: #3092a605">
            最大：{{ $whole_prices['max'] }}円｜

            最小：{{ $whole_prices['min'] }}円｜

            平均：{{ $whole_prices['avg'] }}円｜

            合計：{{ $whole_prices['sum'] }}円
        </p>
        <table class="table">
            <tr>
                <th>ID</th>
                <th>商品名</th>
                <th>カテゴリ</th>
                <th>価格</th>
            </tr>
            {{-- {{ print_r($products[0]) }} --}}
            @foreach ($products as $product)
                <tr>
                    <td>{{ $product->id }}</td>
                    <td>{{ $product->name }}</td>
                    <td>{{ $product->category->name }}</td>
                    <td>{{ $product->price }}</td>
                </tr>
            @endforeach
        </table>
        <p>
            {{-- @if (Request::filled('category')) --}}
            {{ $products->appends(Request::all())->links() }}


        </p>
    </section>
@endsection

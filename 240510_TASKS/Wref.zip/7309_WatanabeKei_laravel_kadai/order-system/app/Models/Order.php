<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Order extends Model
{
    use HasFactory;
    protected $fillable = ['customer_id', 'product_id', 'quantity', 'unit_price', 'shipped_on'];
    public function customer()
    {
        return $this->belongsToMany(Customer::class, 'orders', 'costomers', 'customers.id');
    }
    public function products()
    {
        return $this->belongsToMany(Product::class, 'orders');
    }
    public function orders()
    {
        return $this->hasManyThrough(Product::class, Customer::class);
    }
}

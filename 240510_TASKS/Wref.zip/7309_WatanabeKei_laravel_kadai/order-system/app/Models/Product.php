<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;
    protected $fillable = ['category_id', 'name', 'price'];
    public function category()
    {
        return $this->belongsTo(Category::class);
    }
    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }
    public function maltiSearch($request)
    {
        $finds = [];
        $cnt_value = 0;
        foreach ($request->all() as $key => $value) {
            if ($value != null) {
                if ($key == "price_min" | $key == "price_max") {
                    if ($key == "price_min" && $value != null) {
                        array_push($finds, ['price', '>=', $value]);
                        $cnt_value++;
                    } elseif ($key == "price_max" && $value != null) {
                        array_push($finds, ['price', '<=', $value]);
                        $cnt_value++;
                    }
                } elseif ($key == "name") {
                    array_push($finds, [$key, 'LIKE', '%' . $value . '%']);
                    $cnt_value++;
                } else if ($key == "page") {
                } else {
                    array_push($finds, [$key, '=', $value]);
                    $cnt_value++;
                }
            }
        }
        if ($cnt_value === 0) {
            return Product::withCount('category');
        } elseif ($request->filled('price_min') && $request->filled('price_max')) {
            return Product::withCount('category')->whereBetween('price', [$request->price_min, $request->price_max])->where($finds);
        } elseif ($request->filled('price_min') || $request->filled('price_max')) {
            return Product::withCount('category')->where($finds);
        } else {
            return Product::withCount('category')->where($finds);
        }
    }
}

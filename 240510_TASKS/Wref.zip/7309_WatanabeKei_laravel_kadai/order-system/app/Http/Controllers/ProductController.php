<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $product = new Product;
        $products = $product->maltiSearch($request)->paginate(10);
        $products_all = $product->maltiSearch($request);
        $whole_prices = [
            'max' => $products_all->max('price'),
            'min' => $products_all->min('price'),
            'avg' => $products_all->avg('price'),
            'sum' => $products_all->sum('price')
        ];
        $category = new Category;
        $categories = $category->categories();
        return view('home.index', compact('products', 'categories', 'whole_prices'));
    }
}

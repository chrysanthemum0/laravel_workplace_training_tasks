<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Customer;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Date;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $orders = Order::select(
            '*',
            'products.name as product_name',
            'orders.created_at as order_date',
            'orders.id as order_id'
        )->join(
            'products',
            'orders.product_id',
            '=',
            'products.id'
        )->join(
            'customers',
            'orders.customer_id',
            '=',
            'customers.id'
        )->get();

        return view('orders.index', compact('orders'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $products = Product::all();
        $customers = Customer::all();

        return view('orders.create', compact('products', 'customers'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'customer_id' => 'required',
            'product_id' => 'required',
            'quantity' => 'numeric|between:1,100',
            'unit_price' => 'min:1'
        ]);
        $product_price = Product::select('price')->find($request->product_id)->price;
        $order = new Order;
        $order->customer_id = $request->customer_id;
        $order->product_id = $request->product_id;
        $order->quantity = $request->quantity;
        $order->unit_price =  $product_price * $request->quantity;

        $order->save();
        return redirect(route('orders.index'));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function show(Order $order)
    {
        $orders = $order::select(
            '*',
            'products.name as product_name',
            'orders.created_at as order_date',
            'orders.id as order_id'
        )->join(
            'products',
            'orders.product_id',
            '=',
            'products.id'
        )->join(
            'customers',
            'orders.customer_id',
            '=',
            'customers.id'
        )->where('orders.id', '=', $order->id)->get();

        return view('orders.show', compact('orders'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function edit($order)
    {
        $orders = Order::select(
            '*',
            'products.name as product_name',
            'orders.created_at as order_date',
            'orders.id as order_id'
        )->join(
            'products',
            'orders.product_id',
            '=',
            'products.id'
        )->join(
            'customers',
            'orders.customer_id',
            '=',
            'customers.id'
        )->where('orders.id', '=', $order)->get();
        $products = Product::all();
        $customers = Customer::all();


        return view('orders.edit', compact('orders', 'products', 'customers'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Order $order)
    {
        $this->validate($request, [
            'customer_id' => 'required',
            'product_id' => 'required',
            'quantity' => 'numeric|between:1,100',
            'unit_price' => 'min:1',
            'shipped_on' => 'nullable|date',
        ]);
        $order->update($request->all());
        return redirect(route('orders.index'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function destroy(Order $order)
    {
        $order->delete();
        return redirect(route('orders.index'));
    }
    public function ship(Order $order)
    {
        $date = now();
        $order->shipped_on = $date;
        $order->save();

        return redirect(route('orders.index'));
    }
}
